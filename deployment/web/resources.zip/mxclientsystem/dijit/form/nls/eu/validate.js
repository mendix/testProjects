//>>built
define("dijit/form/nls/eu/validate",{invalidMessage:"Sartutako balioak ez du balio.",missingMessage:"Balio hau beharrezkoa da.",rangeMessage:"Balio hau barrutitik kanpora dago."});
