//>>built
define("dijit/form/nls/sk/Textarea",({iframeEditTitle:"upraviť oblasť",iframeFocusTitle:"upraviť rámec oblasti"}));
